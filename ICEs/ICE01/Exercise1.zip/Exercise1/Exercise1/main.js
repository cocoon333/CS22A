$("div").append("<strong>JavaScript is working!</strong>");
